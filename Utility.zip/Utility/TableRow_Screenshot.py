from typing import List, Dict, Any
import json

from langflow.custom import Component
from langflow.inputs import StrInput, BoolInput, MessageInput
from langflow.template import Output
from langflow.schema import Data


class TableRowScreenshotComponent(Component):
    display_name = "Table Data Extractor & Filter"
    name = "TableDataExtractorFilter"
    description = (
        "Navigates to a URL, reads the HTML table header and body into JSON, "
        "filters rows by search terms, and returns the filtered JSON string."
    )
    icon = "table"

    inputs = [
        MessageInput(
            name="input_text",
            display_name="Input Text",
            info="Wire in a Text Input node here to provide `URL|term1,term2`",
            tool_mode=True
        ),
        StrInput(
            name="url",
            display_name="Page URL",
            value="https://finance.yahoo.com/losers",
            info="Fallback URL if no Input Text is provided"
        ),
        StrInput(
            name="terms",
            display_name="Search Terms",
            value="term1,term2",
            info="Fallback comma-separated terms if no Input Text is provided"
        ),
        BoolInput(
            name="headless",
            display_name="Headless Mode",
            value=True,
            info="Whether to run the browser in headless mode"
        ),
    ]

    outputs = [
        Output(
            name="json_output",
            display_name="Filtered JSON",
            method="run"
        )
    ]

    def run(self) -> Data:
        # 1) Determine URL & search terms
        raw_val = self.input_text
        raw = ""
        if raw_val:
            # handle Message or raw string
            raw = getattr(raw_val, 'content', None) or getattr(raw_val, 'text', None) or str(raw_val)
            raw = raw.strip()
        if raw and "|" in raw:
            url, terms = [p.strip() for p in raw.split("|", 1)]
        else:
            url = self.url
            terms = self.terms

        term_list = [t.lower() for t in terms.split(",") if t.strip()]

        # 2) Browser automation to extract table data
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            raise ImportError("Install 'playwright' and run 'playwright install' to enable browser automation.")

        table_data: List[Dict[str, str]] = []
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=self.headless)
            page = browser.new_page()
            page.goto(url, timeout=60000, wait_until="domcontentloaded")
            # ensure table exists
            page.wait_for_selector("table thead th", timeout=30000)

            # Read headers
            headers = [h.inner_text().strip() for h in page.query_selector_all("table thead th")]

            # Read rows
            for row_el in page.query_selector_all("table tbody tr"):
                cells = row_el.query_selector_all("td")
                values = [c.inner_text().strip() for c in cells]
                # if number of cells matches headers
                if len(values) == len(headers):
                    record = dict(zip(headers, values))
                else:
                    # fallback: index-based keys
                    record = {f"col_{i}": v for i, v in enumerate(values)}
                table_data.append(record)
                print(f"Table record: {record}", flush=True)

            browser.close()

        # 3) Filter rows by presence of any search term
        filtered = []
        for rec in table_data:
            text_blob = " ".join(str(v).lower() for v in rec.values())
            if any(term in text_blob for term in term_list):
                filtered.append(rec)

        # 4) Serialize filtered rows to JSON
        json_str = json.dumps(filtered)
        data = Data(value=json_str)
        self.status = data
        return data
