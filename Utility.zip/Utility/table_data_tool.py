# custom_components/table_data_tool.py

from typing import List, Dict
import json
from langflow.custom import Component
from langflow.inputs import StrInput, BoolInput, MessageInput
from langflow.template import Output
from langflow.schema import Data
from playwright.sync_api import sync_playwright

class TableDataTool(Component):
    display_name = "Extract & Filter Table JSON"
    name = "ExtractTableJSON"
    description = "Reads table at URL, filters rows by terms, returns JSON list."
    icon = "table"

    inputs = [
        MessageInput(
            name="input_text",
            display_name="Input Text",
            info="Wire in a Text Input node here to provide `URL|term1,term2`"
        ),
        StrInput(
            name="url",
            display_name="Page URL",
            value="",
            info="Fallback URL if no Input Text is provided"
        ),
        StrInput(
            name="terms",
            display_name="Search Terms",
            value="term1,term2",
            info="Fallback comma-separated terms if no Input Text is provided"
        ),
        BoolInput(
            name="headless",
            display_name="Headless Mode",
            value=True,
            info="Whether to run the browser in headless mode"
        ),
    ]

    outputs = [
        Output(
            name="json_output",
            display_name="Filtered JSON",
            method="run"
        )
    ]

    def run(self) -> Data:
        # Pull wired-in values (or empty string if nothing wired)
        raw_val = self.input_text
        raw = ""
        if raw_val:
            # handle Message or raw string
            raw = getattr(raw_val, 'content', None) or getattr(raw_val, 'text', None) or str(raw_val)
            raw = raw.strip()
        if raw and "|" in raw:
            url, terms = [p.strip() for p in raw.split("|", 1)]
        else:
            url = self.url
            terms = self.terms

        term_list = [t.lower() for t in terms.split(",") if t.strip()]

        # Scrape the table
        table_data: List[Dict[str, str]] = []
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, wait_until="domcontentloaded")
            page.wait_for_selector("table thead th")

            # headers
            headers = [h.inner_text().strip() for h in page.query_selector_all("table thead th")]

            # rows
            for row_el in page.query_selector_all("table tbody tr"):
                cells = [c.inner_text().strip() for c in row_el.query_selector_all("td")]
                record = dict(zip(headers, cells)) if len(cells) == len(headers) else {f"col_{i}": v for i, v in enumerate(cells)}
                table_data.append(record)
                print(f"record: {record}", flush=True)

            browser.close()

        # Filter rows
        filtered = []
        for rec in table_data:
            blob = " ".join(str(v).lower() for v in rec.values())
            if any(term in blob for term in term_list):
                filtered.append(rec)

        print(f"filtered: {filtered}", flush=True)
        # Return JSON string
        return Data(value=json.dumps(filtered))
