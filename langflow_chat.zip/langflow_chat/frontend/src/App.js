import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import SparkMD5 from 'spark-md5';

function App() {
  // State variables for file, its checksum, and the returned file path.
  const [file, setFile] = useState(null);
  const [fileChecksum, setFileChecksum] = useState('');
  const [filePath, setFilePath] = useState(''); // New: store the server file path
  const [question, setQuestion] = useState('');
  const [conversation, setConversation] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const chatEndRef = useRef(null);

  // Auto-scroll chat view to the latest message.
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [conversation]);

  // Compute the MD5 checksum of the selected file.
  const computeFileChecksum = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (event) => resolve(SparkMD5.hashBinary(event.target.result));
      reader.onerror = (err) => reject(err);
      reader.readAsBinaryString(file);
    });
  };

  // Upload the file to Langflow using the /files/upload endpoint.
  const uploadFile = async (selectedFile) => {
    try {
      const formData = new FormData();
      formData.append("file", selectedFile);
      const FLOW_ID = "d367ecdc-ccc3-46e5-acc8-f93544f1315e"; // <-- Replace with your actual flow ID
      const response = await axios.post(
        `http://host.docker.internal:7860/api/v1/files/upload/${FLOW_ID}`,
        formData,
        { headers: { "Content-Type": "multipart/form-data" } }
      );
      // Expecting a response with a file_path property.
      if (response.data && response.data.file_path) {
        return response.data.file_path;
      }
      return "";
    } catch (err) {
      throw err;
    }
  };

  // Handle file selection.
  const handleFileChange = async (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      try {
        const checksum = await computeFileChecksum(selectedFile);
        const uploadedFiles = JSON.parse(localStorage.getItem('uploadedFiles') || '[]');
        if (uploadedFiles.includes(checksum)) {
          setError("This file is already in Knowledge base.");
          setFile(null);
          setFileChecksum('');
          return;
        } else {
          setFile(selectedFile);
          setFileChecksum(checksum);
          setError('');
          // Auto-upload the file and store the returned file path.
          const uploadedFilePath = await uploadFile(selectedFile);
          setFilePath(uploadedFilePath);
        }
      } catch (err) {
        console.error(err);
        setError("Error processing file.");
      }
    }
  };

  // Handle the submission of a question.
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const uploadedFiles = JSON.parse(localStorage.getItem('uploadedFiles') || '[]');
    // If no new file is selected and nothing has been uploaded before, show an error.
    if (!file && !filePath && uploadedFiles.length === 0) {
      setError("Please upload a document file.");
      return;
    }
    if (!question.trim()) {
      setError("Please enter a question.");
      return;
    }
    // Append the user question to the conversation.
    const newConversation = [...conversation, { type: 'user', text: question }];
    setConversation(newConversation);
    setLoading(true);
    setConversation(prev => [...prev, { type: 'bot', text: "_Processing..._" }]);

    try {
      const formData = new FormData();
      // If a new file is selected, append it.
      if (file) formData.append("file", file);
      formData.append("question", question);

      // Prepare tweaks to pass the file_path to the Document QA flow’s file component.
      // Replace "FileComponent-XYZ" with the actual component ID in your flow.
      const tweaks = filePath ? { "File-8PHIO": { file_path: filePath } } : {};

      // In this example, we assume that the /ask endpoint accepts a "tweaks" parameter.
      // You may need to adjust this to match your backend API.
      formData.append("tweaks", JSON.stringify(tweaks));

      const res = await axios.post("http://localhost:8100/ask", formData);
      let botResponse = res.data.answer;
      try {
        const parsed = JSON.parse(botResponse);
        const inner = parsed?.outputs?.[0]?.outputs?.[0]?.results?.message?.text;
        botResponse = inner || JSON.stringify(parsed, null, 2);
      } catch (err) {
        // If parsing fails, leave the response as-is.
      }
      // Remove the placeholder and append the bot's response.
      setConversation(prev => {
        const updated = [...prev];
        if (updated[updated.length - 1]?.text === "_Processing..._") updated.pop();
        return [...updated, { type: 'bot', text: botResponse }];
      });
      setQuestion('');
      if (file && !uploadedFiles.includes(fileChecksum)) {
        uploadedFiles.push(fileChecksum);
        localStorage.setItem('uploadedFiles', JSON.stringify(uploadedFiles));
      }
    } catch (err) {
      console.error(err);
      setError("Network Error: Could not reach backend.");
      setConversation(prev => {
        const updated = [...prev];
        if (updated[updated.length - 1]?.text === "_Processing..._") updated.pop();
        return updated;
      });
    } finally {
      setLoading(false);
    }
  };

  // Basic inline styles for a modern chat UI.
  const styles = {
    container: {
      display: "flex",
      flexDirection: "column",
      height: "100vh",
      maxWidth: "800px",
      margin: "0 auto",
      fontFamily: "Arial, sans-serif"
    },
    header: {
      backgroundColor: "#202123",
      color: "#fff",
      padding: "16px",
      textAlign: "center",
      fontSize: "24px"
    },
    chatBox: {
      flex: 1,
      padding: "16px",
      overflowY: "auto",
      backgroundColor: "#F7F9FC"
    },
    inputArea: {
      padding: "16px",
      borderTop: "1px solid #ccc",
      backgroundColor: "#fff"
    },
    input: {
      width: "100%",
      padding: "12px",
      fontSize: "16px",
      borderRadius: "4px",
      border: "1px solid #ccc",
      marginBottom: "8px"
    },
    btn: {
      padding: "12px 20px",
      fontSize: "16px",
      backgroundColor: "#0079FF",
      color: "#fff",
      border: "none",
      borderRadius: "4px",
      cursor: "pointer",
      width: "100%",
      opacity: loading ? 0.6 : 1
    },
    userBubble: {
      alignSelf: "flex-end",
      backgroundColor: "#0079FF",
      color: "#fff",
      padding: "10px",
      borderRadius: "16px",
      margin: "4px 0",
      maxWidth: "70%"
    },
    botBubble: {
      alignSelf: "flex-start",
      backgroundColor: "#E5E5EA",
      color: "#000",
      padding: "10px",
      borderRadius: "16px",
      margin: "4px 0",
      maxWidth: "70%"
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>Document Chat</div>
      <div style={styles.chatBox}>
        {conversation.map((msg, i) => (
          <div key={i} style={msg.type === 'user' ? styles.userBubble : styles.botBubble}>
            {msg.type === 'bot' ? (
              <ReactMarkdown
                children={msg.text}
                remarkPlugins={[remarkGfm]}
                components={{
                  code({ node, inline, className, children, ...props }) {
                    return (
                      <code
                        style={{
                          backgroundColor: '#f4f4f4',
                          padding: '2px 4px',
                          borderRadius: '4px',
                          fontSize: '90%'
                        }}
                        {...props}
                      >
                        {children}
                      </code>
                    );
                  }
                }}
              />
            ) : (
              msg.text
            )}
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>
      <div style={styles.inputArea}>
        {error && (
          <div style={{ color: 'red', marginBottom: 8 }}>
            <strong>{error}</strong>
          </div>
        )}
        <form onSubmit={handleSubmit}>
          <input type="file" onChange={handleFileChange} style={styles.input} />
          <textarea
            rows={3}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask your question..."
            style={styles.input}
          />
          <button type="submit" style={styles.btn} disabled={loading}>
            {loading ? "Processing..." : "Send"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default App;
