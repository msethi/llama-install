from fastapi import FastAPI, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
import requests

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_URL = "http://host.docker.internal:7860/api/v1/run/d367ecdc-ccc3-46e5-acc8-f93544f1315e"

@app.post("/ask")
async def ask_question(file: UploadFile = File(None), question: str = Form(...)):
    try:
        payload = {
            "input_value": question,
            "output_type": "chat",
            "input_type": "chat"
        }
        
        # If a new file is provided, add it to the payload
        if file is not None:
            file_bytes = await file.read()
            import base64
            encoded_file = base64.b64encode(file_bytes).decode("utf-8")
            payload["files"] = [encoded_file]
        else:
            payload["files"] = []  # No new file provided; use existing knowledge
        
        headers = {
            "Content-Type": "application/json"
        }
        
        response = requests.post(API_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            return {
                "error": f"Langflow returned {response.status_code}",
                "details": response.text
            }
        
        return {"answer": response.text}
    
    except Exception as e:
        return {"error": str(e)}
